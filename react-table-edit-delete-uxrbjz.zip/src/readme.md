https://kentcdodds.com/blog/javascript-to-know-for-react
https://www.freecodecamp.org/news/javascript-new-features-es2020/
https://kentcdodds.com/blog/common-mistakes-with-react-testing-library
https://kentcdodds.com/blog/should-i-usestate-or-usereducer
https://kentcdodds.com/blog/making-your-ui-tests-resilient-to-change
https://kentcdodds.com/blog/usememo-and-usecallback
https://reactjs.org/docs/hooks-overview.html
https://eloquentjavascript.net/
 https://medium.com/javascript-in-plain-english/lifecycle-methods-substitute-with-react-hooks-b173073052a
https://medium.com/javascript-in-plain-english/lifecycle-methods-substitute-with-react-hooks-b173073052a
https://kentcdodds.com/blog/common-mistakes-with-react-testing-library
https://kentcdodds.com/blog/avoid-nesting-when-youre-testing
 https://kentcdodds.com/blog/testing-implementation-details
https://kentcdodds.com/blog/javascript-to-know-for-react
https://kentcdodds.com/blog/use-ternaries-rather-than-and-and-in-jsx
https://kentcdodds.com/blog/react-hooks-pitfalls
https://kentcdodds.com/blog/how-to-test-custom-react-hooks (edited) 
const requestURL = `https://api.github.com/users/${username}/repos?type=all&sort=updated`;