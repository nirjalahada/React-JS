import React from 'react';

const TableComponent = ({ tableData = [], toEdit, toDelete }) => {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Phone Number</th>
          <th>DOB</th>
          <th>Address</th>
          <th>City</th>
          <th>District</th>
          <th>Province</th>
          <th>Country</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {tableData.map((ele, rowIndex) => {
          return (
            <tr key={`tr-${rowIndex}`}>
              <td>{ele.name}</td>
              <td>{ele.email}</td>
              <td>{ele.phonenumber}</td>
              <td>{ele.dob}</td>
              <td>{ele.address}</td>
              <td>{ele.city}</td>
              <td>{ele.district}</td>
              <td>{ele.province}</td>
              <td>{ele.country}</td>
              <td>
                <a href="#" onClick={(e) => toEdit(e, ele, rowIndex)}>
                  Edit
                </a>{' '}
                <a
                  href="#"
                  onClick={(e) => {
                    toDelete(e, rowIndex);
                  }}
                >
                  Delete
                </a>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default TableComponent;
