import React, { Component } from 'react';
import { render } from 'react-dom';
import { connect } from 'react-redux';
import { MDBDatatable } from 'mdb-react-ui-kit';
import TableComponent from './Component/table';
import './style.css';

let data = [];
let records = {};
let getIndex;

class App extends Component {
  constructor() {
    super();
    this.state = {
      fields: {},
      errors: {},
      isEdit: false,
      updated: false,
    };
  }
  resetData = (fields) => {
    records = {};
    this.setState({ fields: records });
  };

  onChangeState = (e) => {
    const { fields, errors } = this.state;
    let { value, name } = e.target;
    records[name] = value;
    errors[name] = '';
    this.setState({ fields: records });
  };

  handleValidation = (fields) => {
    let errors = {};
    let formIsValid = true;
    //Name
    if (fields) {
      if (!fields['name']) {
        formIsValid = false;
        errors['name'] = 'Cannot be empty';
      }
      //Name
      if (!fields['email']) {
        formIsValid = false;
        errors['email'] = 'Cannot be empty';
      }
      //Name
      if (!fields['phonenumber']) {
        formIsValid = false;
        errors['phonenumber'] = 'Cannot be empty';
      }
      //Name
      if (!fields['dob']) {
        formIsValid = false;
        errors['dob'] = 'Cannot be empty';
      }
      //Name
      if (!fields['address']) {
        formIsValid = false;
        errors['address'] = 'Cannot be empty';
      } //Name
      if (!fields['city']) {
        formIsValid = false;
        errors['city'] = 'Cannot be empty';
      }
      //Name
      if (!fields['district']) {
        formIsValid = false;
        errors['district'] = 'Cannot be empty';
      }
      //Name
      if (!fields['province']) {
        formIsValid = false;
        errors['province'] = 'Cannot be empty';
      }
      //Name
      if (!fields['country']) {
        formIsValid = false;
        errors['country'] = 'Cannot be empty';
      }
    }
    this.setState({ errors: errors });
    return formIsValid;
  };

  onAdd = (e) => {
    e.preventDefault();

    if (this.handleValidation(records)) {
      data = JSON.parse(localStorage.getItem('dataItem')) || [];
      data.push(records);
      localStorage.setItem('dataItem', JSON.stringify(data));
      this.resetData(records);
    }
  };

  toEdit = (e, ele, rowIndex) => {
    getIndex = rowIndex;
    e.preventDefault();

    records = ele;
    this.setState({
      fields: ele,
      isEdit: true,
      update: false,
    });
  };

  toDelete = (e, rowIndex) => {
    e.preventDefault();
    const updateItem = JSON.parse(localStorage.getItem('dataItem'));
    updateItem.splice(rowIndex, 1);
    localStorage.setItem('dataItem', JSON.stringify(updateItem));
    this.setState({ updated: true, isEdit: false });
    this.resetData(records);
  };

  toEditUpdate = (e) => {
    e.preventDefault();
    if (this.handleValidation(records)) {
      const updateItem = JSON.parse(localStorage.getItem('dataItem'));
      updateItem[getIndex] = records;
      localStorage.setItem('dataItem', JSON.stringify(updateItem));
      this.setState({ isEdit: false, updated: true });
      this.resetData(records);
    }
  };

  render() {
    const {
      fields: {
        name,
        email,
        phonenumber,
        dob,
        address,
        city,
        district,
        province,
        country,
      },
      isEdit,
    } = this.state;

    const dataItem = JSON.parse(localStorage.getItem('dataItem')) || [];

    return (
      <div>
        <h1 className="head">Please fill the form</h1>
        <div className="card col-md-6 offset-md-3 offset-md-3">
          <form className="form-data-control">
            <div className="row">
              <div className="form-control">
                <label htmlFor="name" className="label">
                  Name <span style={{ color: 'red' }}>*</span>
                  <input
                    type="text"
                    value={name !== undefined ? name : ''}
                    className="input"
                    name="name"
                    onChange={(e) => this.onChangeState(e)}
                    required
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['name']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="desc" className="label">
                  Email <span style={{ color: 'red' }}>*</span>
                  <input
                    type="email"
                    pattern=".+@globex\.com"
                    value={email !== undefined ? email : ''}
                    className="input"
                    name="email"
                    onChange={(e) => this.onChangeState(e)}
                    required
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['email']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="date" className="label">
                  Phone Number <span style={{ color: 'red' }}>*</span>
                  <input
                    type="number"
                    minlength="7"
                    value={phonenumber !== undefined ? phonenumber : ''}
                    className="input"
                    name="phonenumber"
                    onChange={(e) => this.onChangeState(e)}
                    required
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['phonenumber']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="time" className="label">
                  Date of Birth
                  <input
                    type="text"
                    value={dob !== undefined ? dob : ''}
                    className="input"
                    name="dob"
                    onChange={(e) => this.onChangeState(e)}
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['dob']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="time" className="label">
                  Address
                  <input
                    type="text"
                    value={address !== undefined ? address : ''}
                    className="input"
                    name="address"
                    onChange={(e) => this.onChangeState(e)}
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['address']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="time" className="label">
                  City
                  <input
                    type="text"
                    value={city !== undefined ? city : ''}
                    className="input"
                    name="city"
                    onChange={(e) => this.onChangeState(e)}
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['city']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="time" className="label">
                  District
                  <input
                    type="text"
                    value={district !== undefined ? district : ''}
                    className="input"
                    name="district"
                    onChange={(e) => this.onChangeState(e)}
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['district']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="time" className="label">
                  Province <br></br>
                  {/* <select
                
                  className="select"
                  name="Province"
                  value={province !== undefined ? province : this.state.value}
                  ononChange={(e) => this.onChangeState(e)}
                >
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                </select> */}
                  <input
                    type="number"
                    value={province !== undefined ? province : ''}
                    className="input"
                    name="province"
                    onChange={(e) => this.onChangeState(e)}
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['province']}
                </span>
              </div>
            </div>
            <div className="row">
              <div className="form-control">
                <label htmlFor="time" className="label">
                  Country
                  <input
                    type="text"
                    placeholder="Nepal"
                    value={country !== undefined ? country : ''}
                    className="input"
                    name="country"
                    onChange={(e) => this.onChangeState(e)}
                  />
                </label>
                <span style={{ color: 'red' }}>
                  {this.state.errors && this.state.errors['country']}
                </span>
              </div>
            </div>
            <br></br>
            <div className="row">
              <div className="form-control">
                <button
                  className="button-save"
                  onClick={(e) => this.onAdd(e)}
                  disabled={isEdit}
                >
                  Submit
                </button>
                {isEdit && (
                  <button
                    className="button-save"
                    onClick={(e) => this.toEditUpdate(e)}
                  >
                    Update
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>
        <TableComponent
          tableData={dataItem}
          toEdit={this.toEdit}
          toDelete={this.toDelete}
          isUpated={this.state.updated}
        />
        <br></br>
        <button className='btn'>Profiles</button><br></br>
      </div>
    );
   
  }
}

const mapStateToProps = () => {};

export default connect(null, mapStateToProps)(App);

render(<App />, document.getElementById('root'));
