export const ON_SAVE = 'ON_SAVE';
export const ON_DELETE = 'ON_DELETE';
export const ON_EDIT = 'ON_EDIT';
export const LOADING = 'LOADING';